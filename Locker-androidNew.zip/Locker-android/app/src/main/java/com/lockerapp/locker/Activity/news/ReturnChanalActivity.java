package com.lockerapp.locker.Activity.news;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;

import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.lockerapp.locker.Activity.BaseActivity;
import com.lockerapp.locker.Activity.HomeActivity;
import com.lockerapp.locker.CustomView.TextAwesome;
import com.lockerapp.locker.Model.Chanal;
import com.lockerapp.locker.Model.Locker;
import com.lockerapp.locker.R;
import com.lockerapp.locker.Util.Constant;
import com.lockerapp.locker.Util.Util;
import com.lockerapp.locker.customfonts.MyTextView_Roboto_Bold;
import com.lockerapp.locker.customfonts.MyTextView_Roboto_Regular;

import org.parceler.Parcels;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ReturnChanalActivity extends BaseActivity {

    @BindView(R.id.btn_back)
    TextAwesome btnBack;
    @BindView(R.id.appBar)
    AppBarLayout appBar;
    @BindView(R.id.txt_date_time)
    MyTextView_Roboto_Regular txtDateTime;
    @BindView(R.id.txt_name)
    EditText txtName;
    @BindView(R.id.tel)
    EditText tel;
    @BindView(R.id.price)
    MyTextView_Roboto_Regular Txtprice;
    @BindView(R.id.submit)
    MyTextView_Roboto_Bold submit;
    @BindView(R.id.main_content)
    RelativeLayout mainContent;
    private Chanal chanal;
    private DatabaseReference mRootRef;
    private Locker locker;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_return_chanal);
        ButterKnife.bind(this);
        init();
    }

    private void init() {
        chanal = Parcels.unwrap(getIntent().getParcelableExtra("chanal"));
        locker = Parcels.unwrap(getIntent().getParcelableExtra("locker"));
        mRootRef = FirebaseDatabase.getInstance().getReference();

        mRootRef.child("userRentLocker").child(chanal.id_rent).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    Map<String, Object> map = (Map<String, Object>) dataSnapshot.getValue();
                    long numDay = 0;

                    txtName.setText(map.get("name").toString());


                    try {
                        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                        Date date1 = new java.util.Date();
                        Date date2 = df.parse(map.get("date_rent").toString());

                        long diff = date2.getTime() - date1.getTime();

                        numDay = diff / 1000 / 60 / 60 / 24;

                        txtDateTime.setText(map.get("date_rent").toString() + " ("+numDay+")");
                    } catch (ParseException e) {

                    }

                    if (numDay == 0) {
                        numDay = 1;
                    }

                    long price = chanal.price * numDay;

                    tel.setText(map.get("phone").toString());
                    Txtprice.setText(price+"");




            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    @OnClick({R.id.btn_back, R.id.submit})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                finish();
                break;
            case R.id.submit:
                getSubmit();
                break;
        }
    }

    private void getSubmit() {
        Util.showConfirm2(ReturnChanalActivity.this,
                "ยืนยันการคืนช่อง?", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        getConSubmit();
                    }
                }, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
    }

    private void getConSubmit() {
        showProgressDialog();
        String user_id = mAuth.getCurrentUser().getUid();

        DatabaseReference mEvenRef = mRootRef.child("historyPayment");
        String key2 = mEvenRef.push().getKey();
        HashMap<String, Object> postValues2 = new HashMap<>();

        postValues2.put("date_payment", Constant.DATE_SELECT.toString());
        postValues2.put("userid", user_id);
        postValues2.put("ch_id", chanal.ch_id);
        postValues2.put("id_rent", chanal.id_rent);
        postValues2.put("price", Txtprice.getText().toString());

        mEvenRef.child(Constant.DATE_SELECT.toString()).child(key2).updateChildren(postValues2);


//       update status and set password chanal
        mRootRef.child("lockers").child(locker.key).child(chanal.ch_id).child("password").setValue("");
        mRootRef.child("lockers").child(locker.key).child(chanal.ch_id).child("status").setValue(true);
        mRootRef.child("lockers").child(locker.key).child(chanal.ch_id).child("id_rent").setValue("");

        hideProgressDialog();

        Util.showAlert(ReturnChanalActivity.this,
                "เปิดช่อง และชำระเงินสำเร็จแล้ว",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        Intent intent = new Intent(ReturnChanalActivity.this
                                , HomeActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }
                });
    }
}
