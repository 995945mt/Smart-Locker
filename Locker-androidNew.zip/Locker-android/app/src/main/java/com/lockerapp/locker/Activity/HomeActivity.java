package com.lockerapp.locker.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.lockerapp.locker.Activity.news.ChanalActivity;
import com.lockerapp.locker.Adapters.LockersRecyclerViewAdapter;
import com.lockerapp.locker.CustomView.TextAwesome;
import com.lockerapp.locker.Interface.IClickListener;
import com.lockerapp.locker.Model.Locker;
import com.lockerapp.locker.R;
import com.lockerapp.locker.Util.Constant;
import com.lockerapp.locker.Util.Util;
import com.lockerapp.locker.customfonts.MyTextView_Roboto_Bold;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.parceler.Parcels;
import org.threeten.bp.LocalDate;
import org.threeten.bp.ZoneId;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class HomeActivity extends BaseActivity {


    ArrayList<String> dateOfEvens;
    @BindView(R.id.appBar)
    AppBarLayout appBar;
    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    MyTextView_Roboto_Bold viewAll;
    @BindView(R.id.main_content)
    LinearLayout mainContent;
    @BindView(R.id.btn_logout)
    TextAwesome btnLogout;

    private String TAG = "HomeActivity : ";
    private GridLayoutManager gridLayoutManager;
    private LockersRecyclerViewAdapter adapter;
    private List<Locker> LockerList;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        ButterKnife.bind(this);
        init();
    }

    private void init() {


        gridLayoutManager = new GridLayoutManager(this,3);

        LocalDate instance = LocalDate.now(ZoneId.of("Asia/Bangkok"));
        getListLockers();
        Constant.DATE_SELECT = instance;


    }


    private String setZeroFirstData(int data) {
        String res = "";
        if (data < 10) {
            res = "0" + data;
        } else {
            res = String.valueOf(data);
        }
        return res;
    }

    private void getListLockers() {
        FirebaseDatabase.getInstance().getReference().child("lockers").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<Locker> modelList = new ArrayList<>();



                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                    Locker model = dataSnapshot1.getValue(Locker.class);
                    model.key = dataSnapshot1.getKey();
//                    Chanal model = dataSnapshot1.getValue(Chanal.class);
//                    Locker locker = new Locker();
//                    if (dataSnapshot1.getKey().equals("ch1")) {
//                        locker.ch1 = model;
//                    }else if (dataSnapshot1.getKey().equals("ch2")) {
//                        locker.ch2 = model;
//                    }else {
//                        locker.ch3 = model;
//                    }
//                    Map<String, Object> map = (Map<String, Object>) dataSnapshot1.getValue();
//                    Locker model = new Locker();
//
//                    model.chanal1 = (List<Chanal>) map.get("chanal1");
//
//                    model.date_rent = map.get("date_rent").toString();
//                    model.name = map.get("name").toString();
//                    model.subject = map.get("subject").toString();
//                    model.desc = map.get("desc").toString();
////                    model.timestamp = (long) map.get("timestamp");
//
                    modelList.add(model);


                }



                recyclerView.setLayoutManager(gridLayoutManager);
                LockerList = modelList;

                adapter = new LockersRecyclerViewAdapter(modelList);
                adapter.setOnClickListener(new IClickListener<Integer>() {
                    @Override
                    public void onClick(Integer i) {
                        Intent intent = new Intent(HomeActivity.this, ChanalActivity.class);
                        intent.putExtra("locker",Parcels.wrap(LockerList.get(i)));
                        startActivity(intent);
                    }
                });
                recyclerView.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

                Log.e(TAG, databaseError.getMessage());
            }
        });
    }

    @OnClick(R.id.btn_logout)
    public void onViewClicked() {

        Util.showConfirm(HomeActivity.this, "ยืนยันการออกระบบ?",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        mAuth.removeAuthStateListener(mAuthListener);
                        mAuth.signOut();
                        Intent intent = new Intent(getApplication(), AuthActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }
                }, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
    }
}
