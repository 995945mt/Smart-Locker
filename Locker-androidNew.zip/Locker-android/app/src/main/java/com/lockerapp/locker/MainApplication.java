package com.lockerapp.locker;

import android.app.Application;
import android.content.Context;

import androidx.multidex.MultiDex;
import androidx.multidex.MultiDexApplication;

import com.lockerapp.locker.Util.Contextor;


/**
 * Created by likit on 24/3/2018 AD.
 */

public class MainApplication extends MultiDexApplication {
//    @Override
//    public void onCreate() {
//        super.onCreate();
//        Contextor.getInstance().init(getApplicationContext());
//    }



    @Override
    public void onTerminate() {
        super.onTerminate();
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
        Contextor.getInstance().init(getApplicationContext());
    }
}
