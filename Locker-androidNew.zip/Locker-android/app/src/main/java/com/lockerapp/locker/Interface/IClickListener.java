package com.lockerapp.locker.Interface;

/**
 * Created by likit on 13/7/2560.
 */

public interface IClickListener<T> {
    void onClick(T item);
}