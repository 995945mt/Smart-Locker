package com.lockerapp.locker.Activity.news;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.AppBarLayout;
import com.lockerapp.locker.Activity.BaseActivity;
import com.lockerapp.locker.Activity.HomeActivity;
import com.lockerapp.locker.Adapters.ChanalsRecyclerViewAdapter;
import com.lockerapp.locker.Adapters.LockersRecyclerViewAdapter;
import com.lockerapp.locker.CustomView.TextAwesome;
import com.lockerapp.locker.Interface.IClickListener;
import com.lockerapp.locker.Model.Chanal;
import com.lockerapp.locker.Model.Locker;
import com.lockerapp.locker.R;
import com.lockerapp.locker.Util.Util;

import org.parceler.Parcels;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ChanalActivity extends BaseActivity {

    @BindView(R.id.btn_back)
    TextAwesome btnBack;
    @BindView(R.id.appBar)
    AppBarLayout appBar;
    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.main_content)
    LinearLayout mainContent;

    private List<Chanal> listChanal;
    private Locker locker;
    private GridLayoutManager gridLayoutManager;
    private ChanalsRecyclerViewAdapter adapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chanal);
        ButterKnife.bind(this);

        init();
    }

    private void init() {
        gridLayoutManager = new GridLayoutManager(this,3);
        listChanal = new ArrayList<>();
        locker = Parcels.unwrap(getIntent().getParcelableExtra("locker"));

        Chanal chanal = new Chanal();

        listChanal.add(locker.ch1);
        listChanal.add(locker.ch2);
        listChanal.add(locker.ch3);

        recyclerView.setLayoutManager(gridLayoutManager);


        adapter = new ChanalsRecyclerViewAdapter(listChanal);
        adapter.setOnClickListener(new IClickListener<Integer>() {
            @Override
            public void onClick(Integer i) {

                if (listChanal.get(i).status) {
                    Intent intent = new Intent(ChanalActivity.this, ConfirmChanalActivity.class);
                    intent.putExtra("chanal", Parcels.wrap(listChanal.get(i)));
                    intent.putExtra("locker", Parcels.wrap(locker));
                    startActivity(intent);
                }else {
                    Util.showConfirm(ChanalActivity.this,
                            "ช่องฝากของช่องนี้มีการใช้งานอยู่แล้ว ต้องการเปิดช่องนี้หรือไม่?", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int x) {
                                    Intent intent = new Intent(ChanalActivity.this, OpenChanalActivity.class);
                                    intent.putExtra("chanal", Parcels.wrap(listChanal.get(i)));
                                    intent.putExtra("locker", Parcels.wrap(locker));
                                    startActivity(intent);
                                }
                            },
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                }
                            });
                }
            }
        });
        recyclerView.setAdapter(adapter);
    }

    @OnClick(R.id.btn_back)
    public void onViewClicked() {
        finish();
    }
}
