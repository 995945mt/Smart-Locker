package com.lockerapp.locker.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.lockerapp.locker.R;
import com.lockerapp.locker.Util.Util;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.messaging.FirebaseMessaging;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class AuthActivity extends BaseActivity {


    @BindView(R.id.login)
    TextView login;
    @BindView(R.id.signup)
    TextView signup;
    @BindView(R.id.user)
    EditText user;
    @BindView(R.id.pass)
    EditText pass;
    @BindView(R.id.main_content)
    RelativeLayout mainContent;

    String TAG = "AuthActivity : ";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);
        ButterKnife.bind(this);
        init();
    }

    private void init() {

    }

    @OnClick({R.id.login, R.id.signup})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.login:
                login();
                break;
            case R.id.signup:
                Intent intent = new Intent(getApplication(), RegisterActivity.class);
                startActivity(intent);
                break;
        }
    }

    private void login() {
        if (validate()) {
            mAuth.signInWithEmailAndPassword(user.getText().toString(),
                    pass.getText().toString()
            ).addOnCompleteListener(this,
                    new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful()) {
                                Util.showToast(mainContent,"Username หรือ Password ไม่ถูกต้อง");
                            }else {

                                FirebaseMessaging.getInstance().subscribeToTopic("event")
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                String msg = getString(R.string.msg_subscribed);
                                                if (!task.isSuccessful()) {
                                                    msg = getString(R.string.msg_subscribe_failed);
                                                }
                                                Log.d(TAG, msg);
                                            }
                                        });
//                                Intent intent = new Intent(getApplication(), MainActivity.class);
//                                startActivity(intent);
//                                finish();
                                    Util.showToast(mainContent,"สมัครสมาชิกสำเร็จ อยู่ระหว่าง การจัดทำต่อ");
                            }
                        }
                    });
        }
    }

    private boolean validate() {
        boolean valid = true;
        if (user.getText().length() == 0) {
            user.setError(getString(R.string.user));
            valid = false;
        } else {
            user.setError(null);
        }
        if (pass.getText().length() == 0) {
            pass.setError(getString(R.string.pass));
            valid = false;
        } else {
            pass.setError(null);
        }

        return valid;
    }
}
