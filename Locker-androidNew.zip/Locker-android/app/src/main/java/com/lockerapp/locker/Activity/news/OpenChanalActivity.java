package com.lockerapp.locker.Activity.news;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;

import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.lockerapp.locker.Activity.BaseActivity;
import com.lockerapp.locker.CustomView.TextAwesome;
import com.lockerapp.locker.Model.Chanal;
import com.lockerapp.locker.Model.Locker;
import com.lockerapp.locker.R;
import com.lockerapp.locker.Util.Util;
import com.lockerapp.locker.customfonts.EditText_Roboto_Bold;
import com.lockerapp.locker.customfonts.EditText_Roboto_Italic;
import com.lockerapp.locker.customfonts.MyTextView_Roboto_Bold;

import org.parceler.Parcels;

import java.util.Random;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class OpenChanalActivity extends BaseActivity {

    @BindView(R.id.btn_back)
    TextAwesome btnBack;
    @BindView(R.id.appBar)
    AppBarLayout appBar;
    @BindView(R.id.submit)
    MyTextView_Roboto_Bold submit;
    @BindView(R.id.main_content)
    RelativeLayout mainContent;
    @BindView(R.id.txt_pass)
    EditText_Roboto_Bold txtPass;

    private DatabaseReference mRootRef;
    private Chanal chanal;
    private Locker locker;
    private String TAG = "OpenChanalActivity";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_chanal);
        ButterKnife.bind(this);
        init();
    }

    private void init() {
        mRootRef = FirebaseDatabase.getInstance().getReference();
        chanal = Parcels.unwrap(getIntent().getParcelableExtra("chanal"));
        locker = Parcels.unwrap(getIntent().getParcelableExtra("locker"));
    }

    @OnClick({R.id.btn_back, R.id.submit})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                finish();
                break;
            case R.id.submit:
                getSubmit();
                break;
        }
    }

    private void getSubmit() {
        if (validate()) {
            Util.showConfirm(OpenChanalActivity.this,
                    "ต้องการเปิดช่องเก็บของ?",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            getAction();
                        }
                    }, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    });
        }
    }

    private void getAction() {

        showProgressDialog();
        DatabaseReference mEvenRef = mRootRef.child("lockers").child(locker.key).child(chanal.ch_id);

        mEvenRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Chanal model = dataSnapshot.getValue(Chanal.class);

                hideProgressDialog();

                if (model.password.equals(txtPass.getText().toString())) {
                    Intent intent = new Intent(OpenChanalActivity.this
                            , ReturnChanalActivity.class);
                    intent.putExtra("chanal", Parcels.wrap(model));
                    intent.putExtra("locker", Parcels.wrap(locker));
                    startActivity(intent);
                }else {
                    Util.showAlert(OpenChanalActivity.this,
                            "รหัสผ่านไม่ถูกต้อง", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                }
                            });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                hideProgressDialog();
            }
        });





    }

    private Boolean validate() {
        boolean valid = true;
        if (txtPass.getText().length() == 0) {
            txtPass.setError(getString(R.string.pass));
            valid = false;
        } else {
            txtPass.setError(null);
        }

        return valid;
    }
}
