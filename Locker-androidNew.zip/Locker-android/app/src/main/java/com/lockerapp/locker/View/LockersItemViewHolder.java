package com.lockerapp.locker.View;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.lockerapp.locker.Interface.IClickListener;
import com.lockerapp.locker.Model.Locker;
import com.lockerapp.locker.R;

import butterknife.BindView;
import butterknife.ButterKnife;


public class LockersItemViewHolder extends RecyclerView.ViewHolder {


    View viewG;
    @BindView(R.id.locker_name)
    TextView lockerName;
    @BindView(R.id.list_item)
    LinearLayout listItem;
    @BindView(R.id.locker_address)
    TextView lockerAddress;




    private Locker item;


    public LockersItemViewHolder(View view) {

        super(view);
        viewG = view;
        ButterKnife.bind(this, view);

    }

    public void setItem(Locker item,
                        int position) {
        this.item = item;
        init(position);

    }

    private void init(int position) {

        lockerName.setText(item.name);
        lockerAddress.setText(item.address);
//        time1.setText(item.subject);
//        timeStatus.setText(item.desc);
//
//        groupDiposi.setBackground(viewG.getResources().getDrawable(R.drawable.rect_small_red));
//        ticketAmount.setText(item.name);


    }


    public void setItemClickListener(final IClickListener<Integer> listener, final int index) {

        listItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onClick(index);
            }
        });
    }


}
