package com.lockerapp.locker.View;

import android.graphics.Color;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.lockerapp.locker.Interface.IClickListener;
import com.lockerapp.locker.Model.Chanal;
import com.lockerapp.locker.Model.Locker;
import com.lockerapp.locker.R;

import butterknife.BindView;
import butterknife.ButterKnife;


public class ChanalsItemViewHolder extends RecyclerView.ViewHolder {


    View viewG;
    @BindView(R.id.chanal_name)
    TextView chanalName;
    @BindView(R.id.locker_price)
    TextView lockerPrice;
    @BindView(R.id.locker_status)
    TextView lockerStatus;
    @BindView(R.id.list_item)
    LinearLayout listItem;




    private Chanal item;


    public ChanalsItemViewHolder(View view) {

        super(view);
        viewG = view;
        ButterKnife.bind(this, view);

    }

    public void setItem(Chanal item,
                        int position) {
        this.item = item;
        init(position);

    }

    private void init(int position) {

        chanalName.setText(item.name);
        lockerPrice.setText("ราคา : "+item.price);
//
        if (item.status) {
            lockerStatus.setText("ว่าง");
            lockerStatus.setTextColor(Color.parseColor("#FF4CAF50"));
        }else {
            lockerStatus.setText("ไม่ว่าง");
            lockerStatus.setTextColor(Color.parseColor("#FFF70000"));
        }
//        time1.setText(item.subject);
//        timeStatus.setText(item.desc);
//
//        groupDiposi.setBackground(viewG.getResources().getDrawable(R.drawable.rect_small_red));
//        ticketAmount.setText(item.name);


    }


    public void setItemClickListener(final IClickListener<Integer> listener, final int index) {

        listItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onClick(index);
            }
        });
    }


}
