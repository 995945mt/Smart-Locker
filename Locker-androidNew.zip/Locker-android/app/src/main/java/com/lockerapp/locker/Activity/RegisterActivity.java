package com.lockerapp.locker.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.lockerapp.locker.CustomView.TextAwesome;
import com.lockerapp.locker.R;
import com.lockerapp.locker.Util.Util;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class RegisterActivity extends BaseActivity {

    private static final String TAG = "RegisterActivity : ";
    @BindView(R.id.email)
    EditText email;
    @BindView(R.id.user)
    EditText user;
    @BindView(R.id.pass)
    EditText pass;
    @BindView(R.id.mob)
    EditText mob;
    @BindView(R.id.signup)
    TextView signup;
    @BindView(R.id.login)
    TextView login;
    @BindView(R.id.btn_back)
    TextAwesome btnBack;
    @BindView(R.id.main_content)
    RelativeLayout mainContent;

    private String user_id;
    private DatabaseReference mRootRef;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ButterKnife.bind(this);
        init();
    }

    private void init() {
        mRootRef = FirebaseDatabase.getInstance().getReference();
    }

    @OnClick(R.id.signup)
    public void onViewClicked() {
        if (validate()) {
            showProgressDialog();
            createUser(email.getText().toString(),
                    user.getText().toString(),
                    pass.getText().toString(),
                    mob.getText().toString());
        }
    }

    private boolean validate() {
        boolean valid = true;
        if (email.getText().length() == 0) {
            email.setError(getString(R.string.email));
            valid = false;
        } else {
            email.setError(null);
        }
        if (user.getText().length() == 0) {
            user.setError(getString(R.string.user));
            valid = false;
        } else {
            user.setError(null);
        }
        if (pass.getText().length() == 0) {
            pass.setError(getString(R.string.pass));
            valid = false;
        } else {
            pass.setError(null);
        }
        if (mob.getText().length() == 0) {
            mob.setError(getString(R.string.phone));
            valid = false;
        } else {
            mob.setError(null);
        }

        return valid;
    }

    private void createUser(String email, String username, String password, String tel) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (!task.isSuccessful()) {
                            login.setVisibility(View.VISIBLE);
                            hideProgressDialog();
                        } else {

                            FirebaseInstanceId.getInstance().getInstanceId()
                                    .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                                        @Override
                                        public void onComplete(@NonNull Task<InstanceIdResult> task) {
                                            if (!task.isSuccessful()) {
                                                hideProgressDialog();
                                                Util.showAlert(RegisterActivity.this,
                                                        "กรุณาเชื่อมต่ออินเตอร์เน็ต", new DialogInterface.OnClickListener() {
                                                            @Override
                                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                                dialogInterface.cancel();
                                                            }
                                                        });
                                                return;
                                            } else {


                                                user_id = mAuth.getCurrentUser().getUid();

                                                Map newUserMap = new HashMap();
                                                newUserMap.put("email", email);
                                                newUserMap.put("username", username);
                                                newUserMap.put("phone", tel);
                                                newUserMap.put("type", "user");
                                                newUserMap.put("token", task.getResult().getToken());

                                                Map<String, Object> childUpdates = new HashMap<>();
                                                childUpdates.put("/users/" + user_id, newUserMap);

                                                mRootRef.child("users").child(user_id).updateChildren(newUserMap);

                                                hideProgressDialog();

                                                FirebaseMessaging.getInstance().subscribeToTopic("event")
                                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                String msg = getString(R.string.msg_subscribed);
                                                                if (!task.isSuccessful()) {
                                                                    msg = getString(R.string.msg_subscribe_failed);
                                                                }
                                                                Log.d(TAG, msg);
                                                            }
                                                        });


                                                Util.showToast(mainContent,"สมัครสมาชิกสำเร็จ อยู่ระหว่าง การจัดทำต่อ");

                                                Intent intent = new Intent(getApplication(), HomeActivity.class);
                                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                                startActivity(intent);
                                            }
                                        }
                                    });

                        }
                    }
                });
    }

    @OnClick(R.id.btn_back)
    public void onViewClickedBack() {
        finish();
    }
}
