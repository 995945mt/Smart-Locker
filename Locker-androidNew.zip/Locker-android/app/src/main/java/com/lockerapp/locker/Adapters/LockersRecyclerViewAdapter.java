package com.lockerapp.locker.Adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import com.lockerapp.locker.Interface.IClickListener;
import com.lockerapp.locker.Model.Locker;
import com.lockerapp.locker.R;
import com.lockerapp.locker.View.LockersItemViewHolder;

import java.util.ArrayList;
import java.util.List;

import androidx.recyclerview.widget.RecyclerView;


/**
 * Created by likit on 17/05/2559.
 */
public class LockersRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>
        implements Filterable {

    private LayoutInflater inflater;
    // Keep original data (un-modified by filtering)
    private List<Locker> originalData;

    // Filtered data by criteria
    private List<Locker> filteredData;
    private IClickListener<Integer> clickListener;

    public LockersRecyclerViewAdapter(List<Locker> data) {
        this.originalData = data;
        this.filteredData = data;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        if (inflater == null) {
            inflater = LayoutInflater.from(parent.getContext());
        }

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.locker_recycle, parent, false);

        return new LockersItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {

        LockersItemViewHolder itemViewHolder = (LockersItemViewHolder) holder;

        final Locker item = filteredData.get(position);
        itemViewHolder.setItem(item,position);

        if (this.clickListener != null) {
            itemViewHolder.setItemClickListener(this.clickListener, position);
        }

    }

    @Override
    public int getItemCount() {
        return filteredData.size();
    }

    public void setOnClickListener(IClickListener<Integer> clickListener) {
        this.clickListener = clickListener;
    }


    @Override
    public Filter getFilter() {
        return new Filter() {
            @SuppressWarnings("unchecked")
            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {

                filteredData = (List<Locker>) results.values;
                notifyDataSetChanged();
            }

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {

                List<Locker> filteredResults = new ArrayList<>();



                FilterResults results = new FilterResults();
                results.values = filteredResults;

                return results;
            }
        };
    }

    public void refresh(int index) {
        notifyItemChanged(index);
    }

    public void removeItem(int index) {

        //notifyItemMoved(index+1,index);
        filteredData.remove(index);
        notifyItemRemoved(index);
        notifyItemRangeChanged(index, filteredData.size());

        //notifyItemChanged(index);
        //notifyDataSetChanged();

    }
}