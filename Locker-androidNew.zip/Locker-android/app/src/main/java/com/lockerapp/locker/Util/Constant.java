package com.lockerapp.locker.Util;

import org.threeten.bp.LocalDate;

public class Constant {
    public static String BASE_URL = "http://inter.crru.ac.th/matket-api/";
    public static String JSON_DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static LocalDate DATE_SELECT;

    public static final int RESULT_RENT = 1001;
}
