package com.lockerapp.locker.Activity;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.lockerapp.locker.R;
import com.lockerapp.locker.Util.DialogUtil;
import com.google.firebase.auth.FirebaseAuth;


/**
 * Created by likit on 1/6/2560.
 */

public class BaseActivity extends AppCompatActivity {
    private DialogUtil dialogUtil;
    public FirebaseAuth mAuth;
    public FirebaseAuth.AuthStateListener mAuthListener;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        super.onCreate(savedInstanceState);
        dialogUtil = new DialogUtil(this);

        mAuth = FirebaseAuth.getInstance();

    }

    public void setupWithToobar (Toolbar toolbar){
        this.setSupportActionBar(toolbar);
        this.getSupportActionBar().setHomeButtonEnabled(true);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    public void showProgressDialog(){
        dialogUtil.showProgressDialog(getString(R.string.loading));
    }
    public void showProgressDialog(String message){
        dialogUtil.showProgressDialog(message);
    }
    public void hideProgressDialog(){
        dialogUtil.hideProgressDialog();
    }


}
