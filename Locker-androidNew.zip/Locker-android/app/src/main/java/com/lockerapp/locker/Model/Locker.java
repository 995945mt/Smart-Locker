package com.lockerapp.locker.Model;

import org.parceler.Parcel;

import java.util.List;

@Parcel
public class Locker {
    public String locker_id;
    public String name;
    public String address;
    public Chanal ch1;
    public Chanal ch2;
    public Chanal ch3;
    public String key;

    public Locker(){

    }

    public Locker(String locker_id, String name, String address,
                  Chanal ch1, Chanal ch2, Chanal ch3, String key){
        this.ch1 = ch1;
        this.ch2 = ch2;
        this.ch3 = ch3;
        this.key = key;

    }
}
