package com.lockerapp.locker.Activity.news;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;

import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.lockerapp.locker.Activity.BaseActivity;
import com.lockerapp.locker.Activity.HomeActivity;
import com.lockerapp.locker.CustomView.TextAwesome;
import com.lockerapp.locker.Model.Chanal;
import com.lockerapp.locker.Model.Locker;
import com.lockerapp.locker.R;
import com.lockerapp.locker.Util.Constant;
import com.lockerapp.locker.Util.Util;
import com.lockerapp.locker.customfonts.MyTextView_Roboto_Bold;
import com.lockerapp.locker.customfonts.MyTextView_Roboto_Regular;

import org.parceler.Parcels;

import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.locks.Lock;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class ConfirmChanalActivity extends BaseActivity {

    private static final String TAG = "ConfirmChanalActivity";
    @BindView(R.id.btn_back)
    TextAwesome btnBack;
    @BindView(R.id.appBar)
    AppBarLayout appBar;
    @BindView(R.id.txt_date_time)
    MyTextView_Roboto_Regular txtDateTime;
    @BindView(R.id.txt_name)
    EditText txtName;
    @BindView(R.id.password)
    MyTextView_Roboto_Regular password;
    @BindView(R.id.submit)
    MyTextView_Roboto_Bold submit;
    @BindView(R.id.main_content)
    RelativeLayout mainContent;
    @BindView(R.id.tel)
    EditText tel;


    private Chanal chanal;
    private Random randomGenerator = new Random();
    private DatabaseReference mRootRef;
    private String randomPassword = "";
    private Locker locker;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_chanal);
        ButterKnife.bind(this);
        init();
    }

    private void init() {
        mRootRef = FirebaseDatabase.getInstance().getReference();
        chanal = Parcels.unwrap(getIntent().getParcelableExtra("chanal"));
        locker = Parcels.unwrap(getIntent().getParcelableExtra("locker"));
        txtDateTime.setText(Constant.DATE_SELECT.toString());

        int randomInteger = randomGenerator.nextInt(9999);
        randomPassword = String.format("%04d", randomInteger);

        password.setText(randomPassword);

        Log.i(TAG, Constant.DATE_SELECT.toString());
    }

    @OnClick({R.id.btn_back, R.id.submit})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                break;
            case R.id.submit:
                getSubmit();
                break;
        }
    }

    private void getSubmit() {
        showProgressDialog();
        String user_id = mAuth.getCurrentUser().getUid();

        DatabaseReference mEvenRef = mRootRef.child("historyRentLocker");
        DatabaseReference mUserRentRef = mRootRef.child("userRentLocker");

        String key2 = mEvenRef.push().getKey();
        HashMap<String, Object> postValues2 = new HashMap<>();

        postValues2.put("date_rent", Constant.DATE_SELECT.toString());
        postValues2.put("userid", user_id);
        postValues2.put("ch_id", chanal.ch_id);
        postValues2.put("password", randomPassword);
        postValues2.put("phone", tel.getText().toString());
        postValues2.put("name", txtName.getText().toString());

        mEvenRef.child(Constant.DATE_SELECT.toString()).child(key2).updateChildren(postValues2);
        mUserRentRef.child(key2).updateChildren(postValues2);

//       update status and set password chanal
        mRootRef.child("lockers").child(locker.key).child(chanal.ch_id).child("password").setValue(randomPassword);
        mRootRef.child("lockers").child(locker.key).child(chanal.ch_id).child("status").setValue(false);
        mRootRef.child("lockers").child(locker.key).child(chanal.ch_id).child("id_rent").setValue(key2);

        hideProgressDialog();

        Util.showAlert(ConfirmChanalActivity.this,
                "ปิดช่องสำเร็จแล้ว โปรจำรหัสผ่านเพื่อใช้ในการเปิดช่อง",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        Intent intent = new Intent(ConfirmChanalActivity.this
                                , HomeActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }
                });


    }
}
