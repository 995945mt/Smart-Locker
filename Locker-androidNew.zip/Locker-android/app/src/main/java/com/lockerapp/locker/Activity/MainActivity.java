package com.lockerapp.locker.Activity;

import androidx.annotation.NonNull;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import com.lockerapp.locker.R;
import com.lockerapp.locker.Util.Util;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends BaseActivity {

    private String token;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();

                FirebaseInstanceId.getInstance().getInstanceId()
                        .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                            @Override
                            public void onComplete(@NonNull Task<InstanceIdResult> task) {
                                if (!task.isSuccessful()) {
                                    Util.showAlert(MainActivity.this,
                                            "กรุณาเชื่อมต่ออินเตอร์เน็ต", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialogInterface, int i) {
                                                    dialogInterface.cancel();
                                                }
                                            });
                                    return;
                                }else {

                                    if (user == null) {
                                        Intent intent = new Intent(getApplication(), AuthActivity.class);
                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                        startActivity(intent);
                                    } else {

                                        FirebaseMessaging.getInstance().subscribeToTopic("event")
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        String msg = getString(R.string.msg_subscribed);
                                                        if (!task.isSuccessful()) {
                                                            msg = getString(R.string.msg_subscribe_failed);
                                                        }

                                                    }
                                                });

                                        String userID = FirebaseAuth.getInstance().getCurrentUser().getUid();
                                        final DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("users").child(userID);
                                        token = task.getResult().getToken();
                                        setUpdateToken(ref);
                                        Intent intent = new Intent(getApplication(), HomeActivity.class);
                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                        startActivity(intent);
                                    }
                                }
                            }
                        });
            }
        };

        init();
    }

    private void init() {

    }

    @Override
    protected void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    private void setUpdateToken(DatabaseReference ref) {
        Map userInfo = new HashMap();
        userInfo.put("token", token);
        ref.updateChildren(userInfo);
    }
}
