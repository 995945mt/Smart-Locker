package com.lockerapp.locker.Model;

import org.parceler.Parcel;

@Parcel
public class Chanal {
    public int price;
    public String date_close;
    public String password;
    public boolean status;
    public String name;
    public String ch_id;
    public String id_rent;

    public Chanal(){

    }

    public Chanal(int price, String date_close, String password
            , boolean status, String name, String ch_id,String id_rent){
        this.price = price;
        this.date_close = date_close;
        this.password = password;
        this.status = status;
        this.name = name;
        this.ch_id = ch_id;
        this.id_rent = id_rent;
    }
}
