package com.lockerapp.locker.Util;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.telephony.PhoneNumberUtils;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.lockerapp.locker.R;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.storage.StorageReference;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;


public class Util {

    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    private static Gson gson;

    public static Gson createGson() {
        if (gson == null) {
            gson = new GsonBuilder()
                    .setDateFormat(Constant.JSON_DATE_TIME_FORMAT)
                    .create();
        }
        return gson;
    }

    public static void showToast(View rootView, String text) {

        if (rootView == null || rootView.getContext() == null) {
            Toast.makeText(Contextor.getInstance().getContext()
                    , text
                    , Toast.LENGTH_SHORT).show();
        } else {

            Snackbar.make(rootView, text, Snackbar.LENGTH_SHORT).show();
        }

    }

    public static void showAlert(Context context, String message, DialogInterface.OnClickListener cancleClickListener) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(context, R.style.AlertDialogTheme)
                .setMessage(message)
                .setCancelable(true);
        alertDialog.setNegativeButton("ตกลง", cancleClickListener);
        alertDialog.show();
    }



    public static void showConfirm(Context context, String message, DialogInterface.OnClickListener confirmClickListener, DialogInterface.OnClickListener cancelClickListener) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(context, R.style.AlertDialogTheme)
                .setMessage(message)
                .setCancelable(true);

        alertDialog.setPositiveButton("OK", confirmClickListener);
        alertDialog.setNegativeButton("Cancel", cancelClickListener);

        alertDialog.show();
    }

    public static void showConfirm2(Context context, String message, DialogInterface.OnClickListener confirmClickListener, DialogInterface.OnClickListener cancelClickListener) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(context, R.style.AlertDialogTheme)
                .setMessage(message)
                .setCancelable(true);

        alertDialog.setPositiveButton("ตกลง", confirmClickListener);
        alertDialog.setNegativeButton("ยกเลิก", cancelClickListener);

        alertDialog.show();
    }

    public static String getErrorMessage(ResponseBody errorBody) {
        try {
            JSONObject jsonErrorBody = new JSONObject(errorBody.string());
            return jsonErrorBody.get("OnError").toString();
        } catch (IOException e) {
            return e.getMessage();
        } catch (JSONException e) {
            return e.getMessage();
        }
    }

    public static boolean isValidEmail(CharSequence target) {
        if (target == null) {
            return false;
        } else {
            return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
        }
    }

    public static String getModifireDate() {
        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String formattedDate = df.format(c.getTime());
        return formattedDate;
    }

    public static void verifyStoragePermissions(Activity activity) {
        // Check if we have write permission
        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }
    }

    /*
    public static void loadImage(Context context, String image, ImageView imageView) {
        Glide.with(context)
                .load(image)
                .bitmapTransform(new RoundedCornersTransformation(context, 15, 2))
                .error(R.drawable.noimage)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .dontAnimate()
                .into(imageView);
    }

     */


    public static void loadImage(Context context, String image, ImageView imageView, final ProgressBar progressBar) {
        progressBar.setVisibility(View.VISIBLE);
        Glide.with(context)
                .load(image)
                .error(R.drawable.gallery_icon2)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .dontAnimate()
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        if (progressBar != null) {
                            progressBar.setVisibility(View.GONE);
                        }
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        if (progressBar != null) {
                            progressBar.setVisibility(View.GONE);
                        }
                        return false;
                    }
                })
                .into(imageView);
    }

    public static void loadImage2(Context context, StorageReference image, ImageView imageView, final ProgressBar progressBar) {
        progressBar.setVisibility(View.VISIBLE);
        Glide.with(context)
                .load(image)
                .error(R.drawable.gallery_icon2)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .dontAnimate()
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        if (progressBar != null) {
                            progressBar.setVisibility(View.GONE);
                        }
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        if (progressBar != null) {
                            progressBar.setVisibility(View.GONE);
                        }
                        return false;
                    }
                })
                .into(imageView);
    }


    public static void loadImageCircleImageView(Context context, String image, CircleImageView imageView) {

        Glide.with(context)
                .load(image)
                .error(R.drawable.noimage)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .dontAnimate()
                .into(imageView);
    }

    public static void hideSoftKeyboard(Activity activity) {


        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
    }

    public static Spanned formatHtml(String html) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return Html.fromHtml(html, Html.FROM_HTML_MODE_COMPACT);
        }
        return Html.fromHtml(html);
    }

    public static String numberFormat(Double value){
        DecimalFormat formatter = new DecimalFormat("#,###,###.00");
        if(value==0){
            return "0.00";
        }
        return formatter.format(value);
    }

    public static String phoneFormat(String value){
        return PhoneNumberUtils.formatNumber(value);
    }


    public static boolean DownloadImage(ResponseBody body, ImageView imgView) {

        File externalFilesDir = null;

        try {
            Log.d("DownloadImage", "Reading and writing file");
            InputStream in = null;
            FileOutputStream out = null;

            try {
                in = body.byteStream();
                out = new FileOutputStream(Environment.getExternalStorageDirectory() + File.separator + "AndroidTutorialPoint.jpg");
                int c;

                while ((c = in.read()) != -1) {
                    out.write(c);
                }
            } catch (IOException e) {
                Log.d("DownloadImage", e.toString());
                return false;
            } finally {
                if (in != null) {
                    in.close();
                }
                if (out != null) {
                    out.close();
                }
            }

            int width, height;

            Bitmap bMap = BitmapFactory.decodeFile(Environment.getExternalStorageDirectory() +
                    File.separator + "AndroidTutorialPoint.jpg");
            width = bMap.getWidth();
            height = bMap.getHeight();
            Bitmap bMap2 = Bitmap.createScaledBitmap(bMap, width, height, false);
            imgView.setImageBitmap(bMap2);


            return true;

        } catch (IOException e) {

            Log.d("DownloadImage", e.toString());
            return false;
        }
    }

    public static String conventDate (String day) {
        switch (day) {
            case "MONDAY" :
                day = "จันทร์";
                break;
            case "TUESDAY" :
                day = "อังคาร";
                break;
            case "WEDNESDAY" :
                day = "พุธ";
                break;
            case "THURSDAY" :
                day = "พฤหัสบดี";
                break;
            case "FRIDAY":
                day = "ศุกร์";
                break;
            case "SATURDAY" :
                day = "เสาร์";
                break;
            case "SUNDAY":
                day = "อาทิตย์";
                break;
        }
        return day;
    }

    public static String conventMonth (String month) {
        switch (month) {
            case "JANUARY" :
                month = "มกราคม";
                break;
            case "FEBRUARY" :
                month = "กุมภาพันธ์";
                break;
            case "MARCH" :
                month = "มีนาคม";
                break;
            case "APRIL" :
                month = "เมษายน";
                break;
            case "MAY":
                month = "พฤษภาคม";
                break;
            case "JUNE" :
                month = "มิถุนายน";
                break;
            case "JULY":
                month = "กรกฎาคม";
                break;
            case "AUGUST":
                month = "สิงหาคม";
                break;
            case "SEPTEMBER":
                month = "กันยายน";
                break;
            case "OCTOBER":
                month = "ตุลาคม";
                break;
            case "NOVEMBER":
                month = "พฤศจิกายน";
                break;
            case "DECEMBER":
                month = "ธันวาคม";
                break;
        }
        return month;
    }


    public static void sendMessage(final JSONArray recipients, final String user_id,
                                   final String name, final String user_profile, final String title, final String messageSub) {
        try {
            if (recipients.getString(0).length() > 0)
                new AsyncTask<String, String, String>() {
                    @Override
                    protected String doInBackground(String... params) {
                        try {
                            JSONObject root = new JSONObject();
                            JSONObject notification = new JSONObject();
                            notification.put("title",title);
                            notification.put("body",messageSub);
                            notification.put("content_available",true);
                            notification.put("priority","high");
                            notification.put("sound","defalse");


                            JSONObject message = new JSONObject();
                            message.put("title",title);
                            message.put("body",messageSub);
                            message.put("content_available",true);
                            message.put("priority","high");
                            message.put("sound","defalse");

                            JSONObject data = new JSONObject();
                            data.put("body", notification);

                            root.put("data", message);
                            root.put("to", "/topics/event");
                            root.put("notification",notification);

                            String result = postToFCM(root.toString());
                            Log.d("chat Activity", "Result: " + result);
                            return result;
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                        return null;
                    }

                    @Override
                    protected void onPostExecute(String result) {
                        try {
                            JSONObject resultJson = new JSONObject(result);
                            int success, failure;
                            success = resultJson.getInt("success");
                            failure = resultJson.getInt("failure");
//                            Toast.makeText(LauncherActivity.this, "Message Success: " + success + "Message Failed: " + failure, Toast.LENGTH_LONG).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
//                            Toast.makeText(LauncherActivity.this, "Message Failed, Unknown error occurred.", Toast.LENGTH_LONG).show();
                        }
                    }
                }.execute();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static String postToFCM(String bodyString) throws IOException {

        OkHttpClient mClient = new OkHttpClient();
        final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

        RequestBody body = RequestBody.create(JSON, bodyString);
        Request request = new Request.Builder()
                .url("https://fcm.googleapis.com/fcm/send")
                .post(body)
                .addHeader("Authorization", "key=" + "AAAA5T7-0mc:APA91bHaDBaOngMPWFDChS-ACcFwLgP0qho5knZ5BEIk2LgI62Hmee4Gxf9DfRdGB-Ij9ylw_hBTgOiojssICa5XzphgISKdGnpQBN74_dY9-zfCe-GdR3G3sgUQURt2IeKMxiaWFj9R")
                .build();
        Response response = mClient.newCall(request).execute();
        return response.body().string();
    }
}
